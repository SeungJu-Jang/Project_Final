package com.example.smartfactory;


import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import android.os.StrictMode;
import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ViewFlipper;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.app.NotificationCompat;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;


import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends Activity {


    HttpPost httppost;
    StringBuffer buffer;
    org.apache.http.HttpResponse response;
    HttpClient httpclient;
    List<NameValuePair> nameValuePairs;
    ProgressDialog dialog = null;
    //TextView tv;

    TurnOnOff_Factory.SocketClient client;
    LinkedList<TurnOnOff_Factory.SocketClient> threadList;
    static String u_ip = "192.168.0.12";

    private BackClickHandler backClickHandler;
    private String html = "";
    private Handler mHandler;

    private Socket socket;

    private BufferedReader networkReader = null;
    private BufferedWriter networkWriter = null;

    private int port = 9200; // PORT번호

    @Override
    protected void onStop() {
        super.onStop();
        try {
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mHandler = new Handler();

        try {
            setSocket(u_ip, port);
        } catch (IOException e) {
            e.printStackTrace();
        }
        checkUpdate.start();

        final EditText inputID = (EditText) findViewById(R.id.us_id);
        Button btn = (Button) findViewById(R.id.loginbtn);
        final TextView inputPW = (TextView) findViewById(R.id.us_pw);

        btn.setOnClickListener(new OnClickListener() {

            public void onClick(View v) {


                if ((!inputID.getText().toString().equals("") && (!inputPW.getText().toString().equals("")))) {
                  new Thread(){
                      public void run(){

                          try {
                              String pleaseLogin = "0";
                              PrintWriter outputStream = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
                              outputStream.println(pleaseLogin);

                              BufferedReader in_login = null;
                              in_login = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                              String RequestLogin = in_login.readLine();

                              if(RequestLogin.equals("0")){
                                  try {
                                      String return_msgID = inputID.getText().toString();
                                      String return_msgPW = inputPW.getText().toString();
                                      PrintWriter outputStream2 = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
                                      outputStream2.println(return_msgID +" , " + return_msgPW);
                                      /*outputStream.flush();*/
                                  } catch (IOException e) {
                                      e.printStackTrace();
                                  }
                                  try {
                                      BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                                      String logincnt = in.readLine();

                                      if(logincnt.equals("1")){
                                          Intent intent = new Intent(getApplicationContext(), ManagerMenu.class);
                                          startActivity(intent);
                                      } else if(logincnt.equals("2")){
                                          Intent intent = new Intent(getApplicationContext(), EmployeerMenu.class);
                                          startActivity(intent);
                                      } else if(logincnt.equals("3")){
                                          AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                          builder.setTitle("오류").setMessage("비밀번호가 틀렸습니다.").setCancelable(false).setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                              @Override
                                              public void onClick(DialogInterface dialog, int which) {
                                                  finish();
                                              }
                                          });
                                      }
                                  } catch (IOException e) {
                                      e.printStackTrace();
                                  }
                              }
                          } catch (IOException e) {
                              e.printStackTrace();
                          }

                      }
                  }.start();
                }
                else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle("오류").setMessage("올바른 값을 입력해주세요.").setCancelable(false).setPositiveButton("확인", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }
                    }).show();
                }
            }
        });
    }

    private Thread checkUpdate = new Thread() {

        public void run() {
            try {
                String line;
                Log.w("ChattingStart", "Start Thread");
                while (true) {
                    Log.w("Chatting is running", "chatting is running");
                    line = networkReader.readLine();
                    html = line;
                    mHandler.post(showUpdate);
                }
            } catch (Exception e) {

            }
        }
    };

    private Runnable showUpdate = new Runnable() {

        public void run() {
            Toast.makeText(MainActivity.this, "Coming word: " + html, Toast.LENGTH_SHORT).show();
        }

    };

    public void setSocket(final String ip, final int port) throws IOException {
        new Thread(){
            public void run(){
                try {
                    socket = new Socket(ip, port);
                    networkWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
                    networkReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                } catch (IOException e) {
                    System.out.println(e);
                    e.printStackTrace();
                }
            }
        }.start();


    }





}

