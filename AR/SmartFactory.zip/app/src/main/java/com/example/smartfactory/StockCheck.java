package com.example.smartfactory;


import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class StockCheck extends Activity {
    private static final float FONT_SIZE = 24;
    private FrameLayout container;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stock);

        container = (FrameLayout) findViewById(R.id.framelayout);



        Button button = (Button) findViewById(R.id.turnbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        textview("상품 코드", 380);
        textview("상품 이름", 520);
        textview("상품 단가", 650);

    }

    public void textview(String a, int s){
        TextView view1 = new TextView(this);
        view1.setText(a);
        view1.setTextSize(FONT_SIZE);
        view1.setTextColor(Color.BLACK);

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        params.topMargin = s;
        params.leftMargin = 480;
        view1.setLayoutParams(params);
        container.addView(view1);
    }


}
