package com.example.smartfactory;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import static com.example.smartfactory.TurnOnOff_Factory.socket;

public class RepairEmployeer extends Activity {

    String pleaseLogin = "11";
    PrintWriter outputStream = null;

    EditText name, id, email, pw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_repair_employeer);

        try {
            outputStream = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
            outputStream.println(pleaseLogin);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Button repairemp = (Button) findViewById(R.id.repairgogobtn);
        repairemp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = (EditText)findViewById(R.id.repairname);
                id = (EditText)findViewById(R.id.repairid);
                email = (EditText)findViewById(R.id.repairemail);
                pw = (EditText)findViewById(R.id.repairpw);

                String sname = name.getText().toString();
                String sid = id.getText().toString();
                String semail = email.getText().toString();
                String spw = pw.getText().toString();

                try {
                    outputStream = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
                    outputStream.println(sname + " , " + sid + " , " + semail + " , " + spw + " , ");

                    BufferedReader rerepair = null;
                    rerepair = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    String contextrepair = rerepair.readLine();

                    if(contextrepair.equals("1")){   //직원 정보 제대로 수정 되었을 때
                        AlertDialog.Builder builder = new AlertDialog.Builder(RepairEmployeer.this);
                        builder.setTitle("확인").setMessage("직원정보가 수정되었습니다.").setCancelable(false).setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        }).show();
                    } else if(contextrepair.equals("2")){    //수정 불가한 경우
                        AlertDialog.Builder builder = new AlertDialog.Builder(RepairEmployeer.this);
                        builder.setTitle("오류").setMessage("정확한 값을 입력해주세요.").setCancelable(false).setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        }).show();
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                }



            }
        });

        Button button = (Button) findViewById(R.id.turnbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
