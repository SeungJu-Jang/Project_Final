package com.example.smartfactory;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.LinkedList;

import static com.example.smartfactory.TurnOnOff_Factory.socket;

public class ProtoTypeTest extends Activity {

    Button btn1, btn2, btn3, btn4, btn5, btn6;
    SocketClient client;
    LinkedList<SocketClient> threadList = new LinkedList<SocketClient>();
    static String u_ip = "192.168.0.20";
    static int u_port = 8888;
    static String sendtext = null;
    static Handler msghandler;
    SendThread send;
    private Handler mHandler;
    private String html = "";
    private BufferedReader networkReader = null;
    private BufferedWriter networkWriter = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_proto_type_test);

        btn1 = (Button)findViewById(R.id.loginbtn);
        btn2 = (Button)findViewById(R.id.motoronbtn);
        btn3 = (Button)findViewById(R.id.motoroffbtn);
        btn4 = (Button)findViewById(R.id.goodsbtn);
        btn5 = (Button)findViewById(R.id.empbtn);
       /* btn6 = (Button)findViewById(R.id.moneybtn);*/

        final TextView textView = (TextView)findViewById(R.id.textView3);

        mHandler = new Handler();

        try {
            setSocket(u_ip, u_port);
        } catch (IOException e) {
            e.printStackTrace();
        }
        checkUpdate.start();
        /*msghandler = new Handler() {
            @Override
            public void handleMessage(Message hdmsg) {
                if (hdmsg.what == 1111) {
                    showText.append(hdmsg.obj.toString() + "\n");
                }
            }
        };*/

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(){
                    public void run(){
                        try {
                            String pleaseLogin = "0";
                            PrintWriter outputStream = null;
                            client = new SocketClient(u_ip, u_port);
                            threadList.add(client);
                            client.start();

                            outputStream = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
                            outputStream.println(pleaseLogin);
                            textView.setText(pleaseLogin);

                            BufferedReader in_login = null;
                            in_login = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                            String RequestLogin = in_login.readLine();
                            textView.setText(RequestLogin);

                            if(RequestLogin.equals("0")){
                                String id = "abc";
                                String pw = "1234";

                                outputStream.println(id + " , " + pw);
                                textView.setText(id+ " , " + pw);
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    }
                }.start();

            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(){
                    public void run(){
                        String pleaseLogin = "1";
                        PrintWriter outputStream = null;

                        client = new SocketClient("u_ip", u_port);
                        threadList.add(client);
                        client.start();

                        try {
                            outputStream = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        outputStream.println(pleaseLogin);
                        textView.setText(pleaseLogin);

                    }
                }.start();

            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(){
                    public void run(){
                        client = new SocketClient("u_ip", u_port);
                        threadList.add(client);
                        client.start();

                        String pleaseLogin = "0";
                        PrintWriter outputStream = null;

                        try {
                            outputStream = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        outputStream.println(pleaseLogin);
                        textView.setText(pleaseLogin);

                    }
                }.start();

            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new Thread(){
                    public void run(){
                        client = new SocketClient(u_ip, u_port);
                        threadList.add(client);
                        client.start();

                        try {
                            String pleaseLogin = "12";
                            PrintWriter outputStream = null;

                            outputStream = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
                            outputStream.println(pleaseLogin);
                            textView.setText(pleaseLogin);

                            BufferedReader goodscheck = null;
                            goodscheck = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                            String contxt = null;
                            contxt = goodscheck.readLine();
                            textView.setText(contxt);

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }.start();

            }
        });
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(){
                    public void run(){
                        client = new SocketClient(u_ip, u_port);
                        threadList.add(client);
                        client.start();

                        try {
                            String pleaseLogin = "4";
                            PrintWriter outputStream = null;

                            outputStream = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
                            outputStream.println(pleaseLogin);
                            textView.setText(pleaseLogin);

                            BufferedReader goods = null;
                            goods = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                            String contextgoods = null;
                            contextgoods = goods.readLine();
                            final int goodscnt = Integer.parseInt(contextgoods);
                            for(int i = 0; i<goodscnt; i++){
                                try {
                                    BufferedReader emploeey2 = null;
                                    emploeey2 = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                                    String contxt = null;
                                    contxt = emploeey2.readLine();
                                    textView.setText(contxt);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }.start();

            }
        });
  /*      btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });*/
    }
    static class SocketClient extends Thread {
        boolean threadAlive;
        String ip = u_ip;
        int port = u_port;

        DataOutputStream output = null;


        public SocketClient(String ip, int port) {
            threadAlive = true;
            this.ip = ip;
            this.port = port;
        }

        @Override
        public void run() {

            try {
                // 연결후 바로 ReceiveThread 시작
                socket = new Socket(ip, port);
                output = new DataOutputStream(socket.getOutputStream());

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    class SendThread extends Thread {
        Socket socket;
        String sendtmp=  sendtext;
        String sendmsg = sendtmp ;
        DataOutputStream output;

        public SendThread(Socket socket) {
            this.socket = socket;
            try {
                output = new DataOutputStream(socket.getOutputStream());
            } catch (Exception e) {
            }
        }

        public void run() {

            try {
                // 메세지 전송부
                /*       Log.d(ACTIVITY_SERVICE, "11111");*/

                if (output != null) {
                    if (sendmsg != null) {
                        output.write(sendmsg.getBytes());

                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (NullPointerException npe) {
                npe.printStackTrace();

            }
        }
    }
    private Runnable showUpdate = new Runnable() {

        public void run() {
            Toast.makeText(ProtoTypeTest.this, "Coming word: " + html, Toast.LENGTH_SHORT).show();
        }

    };

    private Thread checkUpdate = new Thread() {

        public void run() {
            try {
                String line;
                Log.w("ChattingStart", "Start Thread");
                while (true) {
                    Log.w("Chatting is running", "chatting is running");
                    line = networkReader.readLine();
                    html = line;
                    mHandler.post(showUpdate);
                }
            } catch (Exception e) {

            }
        }
    };
    public void setSocket(final String ip, final int port) throws IOException {
        new Thread(){
            public void run(){
                try {
                    socket = new Socket(ip, port);
                    networkWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
                    networkReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                } catch (IOException e) {
                    System.out.println(e);
                    e.printStackTrace();
                }
            }
        }.start();


    }
}
