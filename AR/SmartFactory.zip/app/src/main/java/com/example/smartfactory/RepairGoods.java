package com.example.smartfactory;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import static com.example.smartfactory.TurnOnOff_Factory.socket;

public class RepairGoods extends Activity {

    String pleaseLogin = "9";
    PrintWriter outputStream = null;

    EditText rename = (EditText)findViewById(R.id.rename);
    EditText restock = (EditText)findViewById(R.id.restock);


    String setname = rename.getText().toString();
    String setstock = restock.getText().toString();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_repair_goods);

        try {
            outputStream = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
            outputStream.println(pleaseLogin);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Button btn = (Button)findViewById(R.id.repairbtn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BufferedReader goods = null;

                try {
                    outputStream = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
                    outputStream.println(rename + " , "+ restock);

                    BufferedReader rerepair = null;
                    rerepair = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    String contextgoods = rerepair.readLine();

                    if(contextgoods.equals("1")){   //수정 완료
                        AlertDialog.Builder builder = new AlertDialog.Builder(RepairGoods.this);
                        builder.setTitle("확인").setMessage("상품의 재고가 수정되었습니다.").setCancelable(false).setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        }).show();
                    } else if(contextgoods.equals("2")){   //상품 코드가 존재하지 않음
                        AlertDialog.Builder builder = new AlertDialog.Builder(RepairGoods.this);
                        builder.setTitle("오류").setMessage("존재하지 않는 상품코드입니다.").setCancelable(false).setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        }).show();
                    } else if(contextgoods.equals("3")){    //수정하려는 재고가 잘못되었음
                        AlertDialog.Builder builder = new AlertDialog.Builder(RepairGoods.this);
                        builder.setTitle("오류").setMessage("올바른 재고량을 입력해주세요.").setCancelable(false).setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        }).show();
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });

        Button button = (Button) findViewById(R.id.turnbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
