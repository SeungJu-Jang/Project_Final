package com.example.smartfactory;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import static com.example.smartfactory.TurnOnOff_Factory.socket;

public class Plus_goods extends Activity {

    String pleaseLogin = "8";
    PrintWriter outputStream = null;

    EditText etname = (EditText)findViewById(R.id.edgoodsname);
    EditText etstock = (EditText)findViewById(R.id.edgoodsstock);
    EditText etmoney = (EditText)findViewById(R.id.edgoodsmoney);

    String setname = etname.getText().toString();
    String setstock = etstock.getText().toString();
    String setmoney = etmoney.getText().toString();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plus_goods);

        try {
            outputStream = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
            outputStream.println(pleaseLogin);
        } catch (IOException e) {
            e.printStackTrace();
        }


        Button btn = (Button)findViewById(R.id.plusbtn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BufferedReader goods = null;

                try {
                   outputStream = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
                   outputStream.println(setname + " , "+ setstock + " , "+ setmoney);

                    BufferedReader replus = null;
                    replus = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    String contextgoods = replus.readLine();

                    if(contextgoods.equals("1")){   //상품 제대로 추가 되었을 때
                        AlertDialog.Builder builder = new AlertDialog.Builder(Plus_goods.this);
                        builder.setTitle("확인").setMessage("상품이 추가되었습니다.").setCancelable(false).setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        }).show();
                    } else if(contextgoods.equals("2")){    //상품 재고와 단가에 이상이 있을 경우
                        AlertDialog.Builder builder = new AlertDialog.Builder(Plus_goods.this);
                        builder.setTitle("오류").setMessage("올바른 재고와 올바른 단가를 입력해주세요.").setCancelable(false).setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        }).show();
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });

        Button button = (Button) findViewById(R.id.turnbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
