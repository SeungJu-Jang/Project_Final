package com.example.smartfactory;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import static com.example.smartfactory.TurnOnOff_Factory.socket;

public class GoodsCheck extends Activity {

    TextView txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goods_check);

        String pleaseLogin = "7";
        PrintWriter outputStream = null;

        try {
            outputStream = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
            outputStream.println(pleaseLogin);

            txt = (TextView)findViewById(R.id.context);

            Button button2 = (Button) findViewById(R.id.click);
            button2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        BufferedReader goods = null;
                        goods = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        String contextgoods = null;
                        contextgoods = goods.readLine();
                        final int peoplecnt = Integer.parseInt(contextgoods);
                        for(int i = 0; i<peoplecnt; i++){
                            try {
                                BufferedReader emploeey2 = null;
                                emploeey2 = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                                String contxt = null;
                                contxt = emploeey2.readLine();
                                txt.setText(contxt);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });

        } catch (IOException e) {
            e.printStackTrace();
        }



        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Button button2 = (Button) findViewById(R.id.turnbtn);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ManagerMenu.class);
                startActivity(intent);
            }
        });
        Button button3 = (Button) findViewById(R.id.button2);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Plus_goods.class);
                startActivity(intent);
            }
        });
    }


}
