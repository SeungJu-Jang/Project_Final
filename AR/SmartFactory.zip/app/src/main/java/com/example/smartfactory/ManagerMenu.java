package com.example.smartfactory;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.LinkedList;

public class ManagerMenu extends Activity {

    String userID, userPassword, message;
    TextView ManagerT;
    TurnOnOff_Factory.SocketClient client;
    LinkedList<TurnOnOff_Factory.SocketClient> threadList;
    static String u_ip = "192.168.0.141";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager_menu);

        Button button = (Button) findViewById(R.id.stockbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), StockCheck.class);
                startActivity(intent);
            }
        });
        Button button2 = (Button) findViewById(R.id.logoutbtn);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        Button button3 = (Button) findViewById(R.id.goodsbtn);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), GoodsCheck.class);
                startActivity(intent);
            }
        });
        Button button4 = (Button) findViewById(R.id.moneybtn);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MoneyCheck.class);
                startActivity(intent);
            }
        });
        Button button5 = (Button) findViewById(R.id.turnOnOffbtn);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
               client = new TurnOnOff_Factory.SocketClient("u_ip", 9200);
               threadList.add(client);
               client.start();
               Intent intent = new Intent(getApplicationContext(), TurnOnOff_Factory.class);
               startActivity(intent);

            }
        });
        Button button6 = (Button) findViewById(R.id.employeerbtn);
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), EmployeerManager.class);
                startActivity(intent);
            }
        });



    }


}
