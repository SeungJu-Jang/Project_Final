package com.example.smartfactory;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import static com.example.smartfactory.TurnOnOff_Factory.socket;

public class RedrawEmployeer extends Activity {

    String pleaseLogin = "11";
    PrintWriter outputStream = null;

    EditText edt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_redraw_employeer);

        try {
            outputStream = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
            outputStream.println(pleaseLogin);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Button button = (Button) findViewById(R.id.turnbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        Button button2 = (Button) findViewById(R.id.repairbtn);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edt = (EditText)findViewById(R.id.redrawname);
                String edrename = edt.getText().toString();

                try {
                    outputStream = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
                    outputStream.println(edrename);

                    BufferedReader redraw = null;
                    redraw = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    String contextemp = redraw.readLine();

                    if(contextemp.equals("1")){
                        Intent intent = new Intent(getApplicationContext(), RepairEmployeer.class);
                        startActivity(intent);
                    } else if(contextemp.equals("2")){
                        AlertDialog.Builder builder = new AlertDialog.Builder(RedrawEmployeer.this);
                        builder.setTitle("오류").setMessage("직원을 찾을 수 없습니다.").setCancelable(false).setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        }).show();
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                }




            }
        });
    }
}
