package com.example.smartfactory;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import java.util.LinkedList;

public class LoadingActivity extends Activity {

    TurnOnOff_Factory.SocketClient client;
    LinkedList<TurnOnOff_Factory.SocketClient> threadList;
    static String u_ip = "192.168.0.20";
    int u_port = 8888;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loading);
        client = new TurnOnOff_Factory.SocketClient("u_ip", u_port);
        threadList = new LinkedList<TurnOnOff_Factory.SocketClient>();
        threadList.add(client);
        client.start();
        Handler handler = new Handler();
        handler.postDelayed(new Runnable(){
            public void run(){
                /*Intent intent = new Intent(getBaseContext(), MainActivity.class);
                startActivity(intent);*/
                Intent intent = new Intent(getApplicationContext(), ProtoTypeTest.class);
                startActivity(intent);
                finish();
            }
        }, 2000);
    }

}
