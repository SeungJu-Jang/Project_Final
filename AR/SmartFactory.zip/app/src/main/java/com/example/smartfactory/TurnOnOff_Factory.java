package com.example.smartfactory;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.LinkedList;

public class TurnOnOff_Factory extends Activity {

    SendThread send;
    static Socket socket;
    SocketClient client;
    static ReceiveThread receive;
    String nickname ="Manager";
    LinkedList<SocketClient> threadList;
    static String sendtext = null;
    static Handler msghandler;
    TextView showText;
    ProgressDialog dialog = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_turn_on_off__factory);

        Button Button_on = (Button) findViewById(R.id.turnon);
        Button button = (Button)findViewById(R.id.turnbtn);
        threadList = new LinkedList<SocketClient>();

        client = new SocketClient("192.168.43.104", "9000");

        msghandler = new Handler() {
            @Override
            public void handleMessage(Message hdmsg) {
                if (hdmsg.what == 1111) {
                    showText.append(hdmsg.obj.toString() + "\n");
                }
            }
        };

        Button_on.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                sendtext = "1";
                send = new SendThread(socket);
                send.start();
                sendtext = "";
                dialog = ProgressDialog.show(TurnOnOff_Factory.this, "",
                        "메세지 보내는 중...", true);

            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

              Intent intent = new Intent(getApplicationContext(), ManagerMenu.class);
              startActivity(intent);
            }
        });
    }
    static class SocketClient extends Thread {
        boolean threadAlive;
        String ip = "192.168.43.104";
        String port = "9000";

        DataOutputStream output = null;


        public SocketClient(String ip, String port) {
            threadAlive = true;
            this.ip = ip;
            this.port = port;
        }

        @Override
        public void run() {

            try {
                // 연결후 바로 ReceiveThread 시작
                socket = new Socket("192.168.43.104", Integer.parseInt(port));
                output = new DataOutputStream(socket.getOutputStream());
                receive = new ReceiveThread(socket);
                receive.start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    static class ReceiveThread extends Thread {
        private Socket sock = null;
        DataInputStream input;

        public ReceiveThread(Socket socket) {
            this.sock = socket;
            try{
                input = new DataInputStream(sock.getInputStream());
            }catch(Exception e){
            }
        }
        // 메세지 수신후 Handler로 전달
        public void run() {
            try {
                while (input != null) {
                    String msg;
                    int count = input.available();
                    byte[] rcv = new byte[count];
                    input.read(rcv);
                    msg = new String(rcv);

                    if (count > 0) {
                        Log.d(ACTIVITY_SERVICE, "test :" +msg);
                        Message hdmsg = msghandler.obtainMessage();
                        hdmsg.what = 1111;
                        hdmsg.obj = msg;
                        msghandler.sendMessage(hdmsg);
                        Log.d(ACTIVITY_SERVICE,hdmsg.obj.toString());
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    class SendThread extends Thread {
        Socket socket;
        String sendtmp=  sendtext;
        String sendmsg = "["+nickname+"] " + sendtmp +"\n";
        DataOutputStream output;

        public SendThread(Socket socket) {
            this.socket = socket;
            try {
                output = new DataOutputStream(socket.getOutputStream());
            } catch (Exception e) {
            }
        }

        public void run() {

            try {
                // 메세지 전송부
                Log.d(ACTIVITY_SERVICE, "11111");

                if (output != null) {
                    if (sendmsg != null) {
                        output.write(sendmsg.getBytes());

                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (NullPointerException npe) {
                npe.printStackTrace();

            }
        }
    }
}

