package com.example.smartfactory;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.LinkedList;

import static com.example.smartfactory.TurnOnOff_Factory.sendtext;

public class TurnOnOff_Factory extends Activity {

    SendThread send;
    static Socket socket;
    SocketClient client;
    String nickname ="Manager";
    LinkedList<SocketClient> threadList;
    static String sendtext = null;
    static Handler msghandler;
    TextView showText;
    ProgressDialog dialog = null;
    static String u_ip = "192.168.0.12";
    static int u_port = 9200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_turn_on_off__factory);

        Button Button_on = (Button) findViewById(R.id.turnon);
        Button Button_off = (Button) findViewById(R.id.turnoff);
        Button button = (Button)findViewById(R.id.turnbtn);
        threadList = new LinkedList<SocketClient>();

        client = new SocketClient(u_ip, u_port);

        msghandler = new Handler() {
            @Override
            public void handleMessage(Message hdmsg) {
                if (hdmsg.what == 1111) {
                    showText.append(hdmsg.obj.toString() + "\n");
                }
            }
        };

        Button_on.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                sendtext = "1";
                send = new SendThread(socket);
                send.start();
                sendtext = "";

            }
        });
        Button_off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                sendtext = "0";
                send = new SendThread(socket);
                send.start();
                sendtext = "";

            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {

                finish();
            }
        });
    }
    static class SocketClient extends Thread {
        boolean threadAlive;
        String ip = u_ip;
        int port = u_port;

        DataOutputStream output = null;


        public SocketClient(String ip, int port) {
            threadAlive = true;
            this.ip = ip;
            this.port = port;
        }

        @Override
        public void run() {

            try {
                // 연결후 바로 ReceiveThread 시작
                socket = new Socket(ip, port);
                output = new DataOutputStream(socket.getOutputStream());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    static class SendThread extends Thread {
        Socket socket;
        String sendtmp=  sendtext;
        String sendmsg = sendtmp ;
        DataOutputStream output;

        public SendThread(Socket socket) {
            this.socket = socket;
            try {
                output = new DataOutputStream(socket.getOutputStream());
            } catch (Exception e) {
            }
        }

        public void run() {

            try {
                // 메세지 전송부
         /*       Log.d(ACTIVITY_SERVICE, "11111");*/

                if (output != null) {
                    if (sendmsg != null) {
                        output.write(sendmsg.getBytes());

                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (NullPointerException npe) {
                npe.printStackTrace();

            }
        }
    }
}

