package com.example.smartfactory;
import android.util.Log;
import android.widget.TextView;

import java.net.Socket;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class SocketThread {
    static final String SOCKET_IP = "192.168.0.19";
    static int SOCKET_PORT = 8000;
    static Socket socket=null;
    static BufferedReader networkReader = null;
    static BufferedWriter networkWriter = null;

    static SocketThread mSocket;
    public static ArrayList<String> mReadQueue = new ArrayList<String>();
    private SocketThread(){
    }

    static public SocketThread getInstanse(){
        if(mSocket ==null)
            mSocket = new SocketThread();

        return mSocket;
    }

    public BufferedReader getBufferedReader(){
        return networkReader;
    }

    public BufferedReader getnetworkWriter(){
        return networkReader;
    }

    public String getData(){
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return waitRead();
    }

    public void socketWriter(String msg){
        while (socket == null)
        {
            try {
                Thread.sleep(100);
            }catch (Exception e){}
            Log.d("SocketThread", "wait ....socket connect...");
        }
        try {
            Thread.sleep(100);
            PrintWriter outputStream2 = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
            outputStream2.println(msg);
            outputStream2.flush();

        }catch (Exception e) {
            e.printStackTrace();
        }
    }
    Socket SocketStop(){
        try{
            socket.close();
        } catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
    Socket initSocket(){
        try {
            mThread_for_Socket mThread_for_socket = new mThread_for_Socket();
            mThread_for_socket.start();

            Thread.sleep(500);
            mThread_ReadData mThread_readData = new mThread_ReadData();
            mThread_readData.start();
        }catch (Exception e){
            e.printStackTrace();
        }
        return socket;
    }

    public String waitRead() {
        String returnData = "";
        SocketThread mSocketThread = SocketThread.getInstanse();
        while (true) {
            try {
                Thread.sleep(100);
                if (!mSocketThread.mReadQueue.isEmpty()) {
                    for (int i = 0; !mSocketThread.mReadQueue.get(i).isEmpty(); i++) {
                        returnData = mSocketThread.mReadQueue.get(i);
                        mSocketThread.mReadQueue.remove(i);
                        return returnData;
                    }

                }
            } catch (Exception e) {
                return null;
            }

        }
    }

}

class mThreadWrite extends Thread{
    @Override
    public void run() {
        super.run();
    }
}
class mThread_ReadData extends  Thread{
    @Override
    public void run() {
        super.run();
        while(!SocketThread.socket.isClosed()){
            try {
                Thread.sleep(100);
                BufferedReader readData = new BufferedReader(new InputStreamReader(SocketThread.socket.getInputStream()));
                String RequestLogin = readData.readLine();
                SocketThread.mReadQueue.add(RequestLogin);
            }catch (Exception e){
                e.printStackTrace();
            }
        }

    }

}
class mThread_for_Socket extends Thread {
    @Override
    public void run() {
        super.run();
        try {
            SocketThread.socket = new Socket(SocketThread.SOCKET_IP, SocketThread.SOCKET_PORT);

            SocketThread.networkWriter = new BufferedWriter(new OutputStreamWriter(SocketThread.socket.getOutputStream()));
            SocketThread.networkReader = new BufferedReader(new InputStreamReader(SocketThread.socket.getInputStream()));

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}