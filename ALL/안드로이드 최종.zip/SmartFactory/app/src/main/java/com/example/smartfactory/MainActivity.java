package com.example.smartfactory;


import android.os.Handler;
import android.os.Looper;
import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View.OnClickListener;
import android.widget.TextView;


public class MainActivity extends Activity {

    private Handler mHandler;

    @Override
    protected void onStop() {
        super.onStop();
/*        try {
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }*/
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mHandler = new Handler();

       final SocketThread mSocketThread = SocketThread.getInstanse();
       mSocketThread.initSocket();

        final EditText inputID = (EditText) findViewById(R.id.us_id);
        Button btn = (Button) findViewById(R.id.loginbtn);
        final TextView inputPW = (TextView) findViewById(R.id.us_pw);

        btn.setOnClickListener(new OnClickListener() {

            public void onClick(View v) {


                if ((!inputID.getText().toString().equals("") && (!inputPW.getText().toString().equals("")))) {
                  new Thread(){
                      public void run(){

                          try {
                              String pleaseLogin = "login";
                              mSocketThread.socketWriter(pleaseLogin);
                              String RequestLogin = mSocketThread.getData();

                              Log.d("TAG", RequestLogin);

                              if(RequestLogin.equals("0")){
                                  try {
                                      String return_msgID = inputID.getText().toString();
                                      String return_msgPW = inputPW.getText().toString();

                                      mSocketThread.socketWriter(return_msgID +"  " + return_msgPW);
                                  } catch (Exception e) {
                                      e.printStackTrace();
                                  }
                                  try {
                                      String logincnt =  mSocketThread.getData();
                                      Log.d("logincnt : ", logincnt);

                                      if(logincnt.equals("1")){
                                          Intent intent = new Intent(getApplicationContext(), ManagerMenu.class);
                                          startActivity(intent);
                                          mSocketThread.SocketStop();
                                      } else if(logincnt.equals("2")){
                                          Intent intent = new Intent(getApplicationContext(), EmployeerMenu.class);
                                          startActivity(intent);
                                      } else if(logincnt.equals("3")){

                                          Handler mHandler = new Handler(Looper.getMainLooper());
                                          mHandler.postDelayed(new Runnable() {
                                              @Override
                                              public void run() {
                                                  AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                                  builder.setTitle("오류").setMessage("비밀번호가 틀렸습니다.").setCancelable(false).setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                                      @Override
                                                      public void onClick(DialogInterface dialog, int which) {
                                                          finish();
                                                      }
                                                  }).show();
                                              }
                                          }, 0);
                                      } else if(logincnt.equals("4")){
                                          Handler mHandler = new Handler(Looper.getMainLooper());
                                          mHandler.postDelayed(new Runnable() {
                                              @Override
                                              public void run() {
                                                  AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                                                  builder.setTitle("오류").setMessage("아이디가 틀렸습니다.").setCancelable(false).setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                                      @Override
                                                      public void onClick(DialogInterface dialog, int which) {
                                                          finish();
                                                      }
                                                  }).show();
                                              }
                                          }, 0);
                                      }
                                  } catch (Exception e) {
                                      e.printStackTrace();
                                  }
                              }
                          } catch (Exception e) {
                              e.printStackTrace();
                          }

                      }
                  }.start();
                }
                else {
                    /*AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setTitle("오류").setMessage("올바른 값을 입력해주세요.").setCancelable(false).setPositiveButton("확인", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }
                    }).show();*/
                    Intent intent = new Intent(getApplicationContext(), ManagerMenu.class);
                    startActivity(intent);
                    mSocketThread.SocketStop();
                }
            }
        });
    }

}

