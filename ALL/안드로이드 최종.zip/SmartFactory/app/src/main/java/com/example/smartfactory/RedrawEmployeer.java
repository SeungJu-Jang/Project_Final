package com.example.smartfactory;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.LinkedList;


public class RedrawEmployeer extends Activity {

    String pleaseLogin = "throwid";

    EditText edt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_redraw_employeer);

        final SocketThread mSocketThread = SocketThread.getInstanse();
        mSocketThread.initSocket();


        Button button = (Button) findViewById(R.id.turnbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();

            }
        });
        Button button2 = (Button) findViewById(R.id.repairbtn);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edt = (EditText)findViewById(R.id.redrawname);


                new Thread(){
                    public void run(){
                        try {

                            mSocketThread.socketWriter(pleaseLogin);
                            Log.d("TAG", pleaseLogin);

                            String dataset = mSocketThread.getData();
                            Log.d("TAG", dataset);
                            final String edrename = edt.getText().toString();

                            if(dataset.equals("0")){
                                mSocketThread.socketWriter(edrename);
                                Log.d("TAG", edrename);
                            }

                            String contextemp = mSocketThread.getData();
                            Log.d("TAG", contextemp);

                            if(contextemp.equals("1")){
                                Intent intent = new Intent(getApplicationContext(), RepairEmployeer.class);
                                startActivity(intent);
                                mSocketThread.SocketStop();
                            } else if(contextemp.equals("2")){
                                Handler mHandler = new Handler(Looper.getMainLooper());
                                mHandler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        AlertDialog.Builder builder = new AlertDialog.Builder(RedrawEmployeer.this);
                                        builder.setTitle("오류").setMessage("직원을 찾을 수 없습니다.").setCancelable(false).setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                mSocketThread.SocketStop();
                                                finish();
                                            }
                                        }).show();
                                    }
                                },0);
                            }


                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }.start();

            }
        });
    }
}
