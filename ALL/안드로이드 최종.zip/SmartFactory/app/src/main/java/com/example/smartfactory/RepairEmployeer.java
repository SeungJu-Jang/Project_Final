package com.example.smartfactory;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.security.spec.ECField;
import java.util.LinkedList;

public class RepairEmployeer extends Activity {

    String pleaseLogin = "repairemp";
    EditText name, email, pw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_repair_employeer);

        final SocketThread mSocketThread = SocketThread.getInstanse();
        mSocketThread.initSocket();

        name = (EditText)findViewById(R.id.repairname);
        email = (EditText)findViewById(R.id.repairemail);
        pw = (EditText)findViewById(R.id.repairpw);

        Button repairemp = (Button) findViewById(R.id.repairgogobtn);
        repairemp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new Thread(){
                    public void run(){

                        try {
                            mSocketThread.socketWriter(pleaseLogin);
                            Log.d("TAG", pleaseLogin);

                            String dataset = mSocketThread.getData();
                            Log.d("TAG",dataset);

                            String sname = name.getText().toString();
                            String semail = email.getText().toString();
                            String spw = pw.getText().toString();

                            if(dataset.equals("0")){

                                String data = sname + "/" +  spw + "/" + semail;
                                mSocketThread.socketWriter(data);
                                Log.d("TAG", data);
                            }

                            String contextrepair = mSocketThread.getData();

                            if(contextrepair.equals("1")){   //직원 정보 제대로 수정 되었을 때
                                Handler mHandler = new Handler(Looper.getMainLooper());
                                mHandler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        AlertDialog.Builder builder = new AlertDialog.Builder(RepairEmployeer.this);
                                        builder.setTitle("확인").setMessage("직원정보가 수정되었습니다.").setCancelable(false).setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                mSocketThread.SocketStop();
                                                finish();
                                            }
                                        }).show();
                                    }
                                },0);
                            } else if(contextrepair.equals("2")){    //수정 불가한 경우
                                Handler mHandler = new Handler(Looper.getMainLooper());
                                mHandler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        AlertDialog.Builder builder = new AlertDialog.Builder(RepairEmployeer.this);
                                        builder.setTitle("오류").setMessage("올바른 값을 입력해주세요.").setCancelable(false).setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                mSocketThread.SocketStop();
                                            }
                                        }).show();
                                    }
                                },0);
                            }


                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }.start();

            }
        });

        Button button = (Button) findViewById(R.id.turnbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
