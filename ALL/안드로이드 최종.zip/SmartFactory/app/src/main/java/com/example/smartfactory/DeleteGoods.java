package com.example.smartfactory;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.LinkedList;


public class DeleteGoods extends Activity {

    String pleaseLogin = "delete";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_goods);

        final SocketThread mSocketThread = SocketThread.getInstanse();
        mSocketThread.initSocket();
        final EditText delcode = (EditText)findViewById(R.id.delgoods);

        Button delbtn = (Button) findViewById(R.id.deletebtn);
        delbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new Thread(){
                    public void run(){
                        try {
                            mSocketThread.socketWriter(pleaseLogin);
                            Log.d("TAG", pleaseLogin);

                            String dataset = mSocketThread.getData();
                            Log.d("TAG", dataset);
                            if(dataset.equals("0")){
                                String sdelcode = delcode.getText().toString();
                                mSocketThread.socketWriter(sdelcode);
                                Log.d("TAG", sdelcode);
                            }

                            String contextgoods = mSocketThread.getData();

                            Log.d("TAG", contextgoods);
                            if(contextgoods.equals("1")){   //상품 제대로 삭제 되었을 때
                                Handler mHandler = new Handler(Looper.getMainLooper());
                                mHandler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        AlertDialog.Builder builder = new AlertDialog.Builder(DeleteGoods.this);
                                        builder.setTitle("확인").setMessage("상품이 삭제되었습니다.").setCancelable(false).setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                mSocketThread.SocketStop();
                                                finish();
                                            }
                                        }).show();
                                    }
                                },0);
                            } else if(contextgoods.equals("2")){    //상품 코드가 없을 경우
                                Handler mHandler = new Handler(Looper.getMainLooper());
                                mHandler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        AlertDialog.Builder builder = new AlertDialog.Builder(DeleteGoods.this);
                                        builder.setTitle("확인").setMessage("상품이 코드가 존재하지 않습니다.").setCancelable(false).setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {

                                            }
                                        }).show();
                                    }
                                },0);
                            }


                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }.start();
            }
        });

        Button button = (Button) findViewById(R.id.turnbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                mSocketThread.SocketStop();
            }
        });
    }
}
