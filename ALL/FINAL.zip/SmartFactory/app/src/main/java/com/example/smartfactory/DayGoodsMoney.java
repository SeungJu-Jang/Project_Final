package com.example.smartfactory;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import java.io.PrintWriter;


public class DayGoodsMoney extends Activity {


    TextView stxtdate, stxtcode, stxtname, stxtsales, stotalmoney, sdate;
    static String sNum1 = "";
    static String sNum2 = "";
    static String sNum3 = "";
    static String sNum4 = "";
    static String sNum5 = "";
    static String setdate = "";
    String []Arr = new String[20];
    private DatePickerDialog.OnDateSetListener callbackMethod;

    String date = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_day_goods_money);

        final SocketThread mSocketThread = SocketThread.getInstanse();
        mSocketThread.initSocket();

        stxtdate = (TextView)findViewById(R.id.txtdate);
        stxtcode = (TextView)findViewById(R.id.txtcode);
        stxtname = (TextView)findViewById(R.id.txtname);
        stxtsales = (TextView)findViewById(R.id.txtsales);
        stotalmoney = (TextView)findViewById(R.id.totalmoney);
        sdate = (TextView)findViewById(R.id.datenum);

        this.InitializeListener();

        Button btn1 = (Button)findViewById(R.id.click);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread() {
                    public void run() {
                        try {
                            String pleaseLogin = "money";
                            mSocketThread.socketWriter(pleaseLogin);
                            Log.d("TAG", pleaseLogin);

                            String contextEmp = mSocketThread.getData();
                            Log.d("TAG", contextEmp);

                            final int count = Integer.parseInt(contextEmp);

                            if(contextEmp !=null){
                                pleaseLogin = "take";
                                mSocketThread.socketWriter(pleaseLogin);
                                Log.d("TAG", pleaseLogin);

                                String dataset = mSocketThread.getData();
                                if(dataset.equals("0")){
                                    mSocketThread.socketWriter(date);
                                    Log.d("TAG", date);
                                }
                            }
                            else{
                                Log.d("TAG", "not receive");
                            }

                            int num = 1;
                            if(num == 1){
                                try {
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            stxtdate.setText(date);
                                        }
                                    });

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                num++;
                            }
                            if(num == 2){
                                try {
                                    for(int k = 0; k<count; k++){
                                        try {
                                            Arr[k] = mSocketThread.getData()+"\n";
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }
                                    for(int k = 0; k<count; k++){
                                        sNum2 += Arr[k] ;
                                    }

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                num++;
                            }
                            if(num == 3){
                                try {
                                    for(int u = 0; u<count; u++){
                                        try {
                                            Arr[u] = mSocketThread.getData()+"\n";
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }
                                    for(int u = 0; u<count; u++){
                                        sNum3 += Arr[u] ;
                                    }

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                num++;
                            }
                            if(num == 4){
                                try {
                                    for(int j = 0; j<count; j++){
                                        try {
                                            Arr[j] = mSocketThread.getData()+"\n";
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }
                                    for(int j = 0; j<count; j++){
                                        sNum4 += Arr[j] ;
                                    }

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                num++;
                            }
                            if(num == 5){
                                try {
                                        try {
                                            setdate = "give";
                                            mSocketThread.socketWriter(setdate);
                                            Log.d("TAG", setdate);

                                            Arr[0] = mSocketThread.getData()+"\n";
                                            Log.d("TAG", Arr[0]);
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                        sNum5 = Arr[0] ;

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }

                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    stxtcode.setText(sNum2);
                                    stxtname.setText(sNum3);
                                    stxtsales.setText(sNum4);
                                    stotalmoney.setText(sNum5);
                                }
                            });

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }.start();
            }
        });

        Button button = (Button) findViewById(R.id.turnbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                mSocketThread.SocketStop();
            }
        });
    }

    public void InitializeListener()
    {
        callbackMethod = new DatePickerDialog.OnDateSetListener()
        {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                if(month <10){
                    if(dayOfMonth <10){
                        date = year + "-" + "0" +(1+month)+ "-" + "0" + dayOfMonth;
                        sdate.setText(date);
                    } else{
                        date = year + "-" + "0" +(1+month)+ "-" + dayOfMonth;
                        sdate.setText(date);
                    }
                    } else{
                    if(dayOfMonth <10){
                        date = year + "-" + (1+month)+ "-" + "0" + dayOfMonth;
                        sdate.setText(date);
                    } else{
                        date = year + "-" + (1+month)+ "-" + dayOfMonth;
                        sdate.setText(date);
                    }
                }
            }
        };
    }

    public void OnClickHandler(View view)
    {
        DatePickerDialog dialog = new DatePickerDialog(this, callbackMethod, 2020, 3, 20);

        dialog.show();
    }
}
