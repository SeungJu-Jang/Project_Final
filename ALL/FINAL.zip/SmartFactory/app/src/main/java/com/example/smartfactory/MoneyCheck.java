package com.example.smartfactory;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MoneyCheck extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_money_check);

        final SocketThread mSocketThread = SocketThread.getInstanse();
        mSocketThread.initSocket();

        Button button = (Button) findViewById(R.id.turnbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                mSocketThread.SocketStop();
            }
        });
        Button button2 = (Button) findViewById(R.id.daybtn);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), DayGoodsMoney.class);
                startActivity(intent);
                mSocketThread.SocketStop();
            }
        });

    }
}
