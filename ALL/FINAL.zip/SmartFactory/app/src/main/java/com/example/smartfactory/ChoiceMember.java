package com.example.smartfactory;


import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ChoiceMember extends Activity {

    static String sNum1 = "";
    static String sNum2 = "";
    static String sNum3 = "";
    static String sNum4 = "";
    String []Arr = new String[30];

    int peoplecnt = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice_member);

        final TextView txt = (TextView)findViewById(R.id.txtnumber);
        final TextView txt2 = (TextView)findViewById(R.id.txtgrade);
        final TextView txt3 = (TextView)findViewById(R.id.txtname);
        final TextView txt4 = (TextView)findViewById(R.id.txtid);

        final SocketThread mSocketThread = SocketThread.getInstanse();
        mSocketThread.initSocket();

        Button btn1 = (Button) findViewById(R.id.click);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new Thread(new Runnable() {
                    @Override
                    public void run() {

                        try {
                            String pleaseLogin = "user";

                            mSocketThread.socketWriter(pleaseLogin);

                            String contextgoods = mSocketThread.waitRead();
                            //Log.d("TAG", contextgoods);

                            if(contextgoods!=null){
                                pleaseLogin = "send";
                                mSocketThread.socketWriter(pleaseLogin);
                                Log.d("TAG", pleaseLogin);
                            }
                            else{
                                Log.d("TAG", "not receive");
                            }

                            final int peoplecnt = Integer.parseInt(contextgoods);

                            int num = 1;
                            if(num == 1){
                                try {
                                    for(int i = 0; i<peoplecnt; i++){
                                        try {
                                            Arr[i] = mSocketThread.waitRead()+"\n";
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }
                                    for(int i = 0; i<peoplecnt; i++){
                                        sNum1 += Arr[i] ;
                                    }

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                num++;
                            }
                            if(num == 2){
                                try {
                                    for(int k = 0; k<peoplecnt; k++){
                                        try {
                                            Arr[k] = mSocketThread.waitRead()+"\n";
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }
                                    for(int k = 0; k<peoplecnt; k++){
                                        sNum2 += Arr[k] ;
                                    }

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                num++;
                            }
                            if(num == 3){
                                try {
                                    for(int u = 0; u<peoplecnt; u++){
                                        try {
                                            Arr[u] = mSocketThread.waitRead()+"\n";
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }
                                    for(int u = 0; u<peoplecnt; u++){
                                        sNum3 += Arr[u] ;
                                    }

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                num++;
                            }
                            if(num == 4){
                                try {
                                    for(int j = 0; j<peoplecnt; j++){
                                        try {
                                            Arr[j] = mSocketThread.waitRead()+"\n";
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }
                                    for(int j = 0; j<peoplecnt; j++){
                                        sNum4 += Arr[j] ;
                                    }

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    txt.setText(sNum1);
                                    txt2.setText(sNum2);
                                    txt3.setText(sNum3);
                                    txt4.setText(sNum4);
                                }
                            });
                        } catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                }).start();

                }
        });

        Button button = (Button) findViewById(R.id.turnbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSocketThread.SocketStop();
                finish();

            }
        });

    }
}
