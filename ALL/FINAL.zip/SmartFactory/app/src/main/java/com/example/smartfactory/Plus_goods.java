package com.example.smartfactory;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.LinkedList;

public class Plus_goods extends Activity {

    String pleaseLogin = "plus";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plus_goods);

        final SocketThread mSocketThread = SocketThread.getInstanse();
        mSocketThread.initSocket();

        final EditText etname = (EditText)findViewById(R.id.edgoodsname);
        final EditText etstock = (EditText)findViewById(R.id.edgoodsstock);
        final EditText etmoney = (EditText)findViewById(R.id.edgoodsmoney);
        final EditText etbrand = (EditText)findViewById(R.id.edgoodsbrand);
        final EditText etcode = (EditText)findViewById(R.id.edgoodscode);

        Button btn = (Button)findViewById(R.id.plusbtn);



        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BufferedReader goods = null;

                new Thread(){
                    public void run(){
                        try {
                            mSocketThread.socketWriter(pleaseLogin);
                            Log.d("TAG", pleaseLogin);

                            final String setbrand = etbrand.getText().toString();
                            final String setname = etname.getText().toString();
                            final String setcode = etcode.getText().toString();
                            final String setmoney = etmoney.getText().toString();
                            final String setstock = etstock.getText().toString();

                            String dataset = mSocketThread.waitRead();
                            if(dataset.equals("0")){
                                Log.d("TAG", dataset);
                                String text = setbrand + "/"+ setname + "/"+ setcode + "/" + setmoney + "/" + setstock;

                                mSocketThread.socketWriter(text);

                                Log.d("TAG",text);
                            }

                            String contextgoods = mSocketThread.waitRead();
                            Log.d("TAG", contextgoods);

                            if(contextgoods.equals("1")){   //상품 제대로 추가 되었을 때
                                Handler mHandler = new Handler(Looper.getMainLooper());
                                mHandler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        AlertDialog.Builder builder = new AlertDialog.Builder(Plus_goods.this);
                                        builder.setTitle("확인").setMessage("상품이 추가되었습니다.").setCancelable(false).setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                mSocketThread.SocketStop();
                                                finish();
                                            }
                                        }).show();
                                    }
                                },0);
                            } else if(contextgoods.equals("2")){    //상품 재고와 단가에 이상이 있을 경우
                                Handler mHandler = new Handler(Looper.getMainLooper());
                                mHandler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        AlertDialog.Builder builder = new AlertDialog.Builder(Plus_goods.this);
                                        builder.setTitle("오류").setMessage("올바른 정보를 입력해주세요.").setCancelable(false).setPositiveButton("확인", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                mSocketThread.SocketStop();
                                            }
                                        }).show();
                                    }
                                },0);
                            }


                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }.start();



            }
        });

        Button button = (Button) findViewById(R.id.turnbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSocketThread.SocketStop();
                finish();
            }
        });
    }
}
