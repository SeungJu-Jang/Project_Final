package com.example.smartfactory;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.LinkedList;
import java.util.List;



public class StockCheck extends Activity {

    private Handler mHandler;

    @Override
    protected void onStop() {
        super.onStop();
      /*  try {
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }*/
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stock);

        mHandler = new Handler();

        final SocketThread mSocketThread = SocketThread.getInstanse();
        mSocketThread.initSocket();

        Button btn = (Button)findViewById(R.id.checkbtn);
        final TextView txtbrand = (TextView)findViewById(R.id.textbrand);
        final TextView txtname = (TextView)findViewById(R.id.textname);
        final TextView txtcode = (TextView)findViewById(R.id.textcode);
        final TextView txtmoney = (TextView)findViewById(R.id.textmoney);
        final TextView txtstock = (TextView)findViewById(R.id.textstock);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("hi", "msg1");
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            String pleaseLogin = "goods";
                            Log.d("hi", pleaseLogin);
                            mSocketThread.socketWriter(pleaseLogin);
                            Log.d("hi ", "msg1");
                            String Requestnum = mSocketThread.waitRead();
                            if (Requestnum.equals("0")) {
                                final String stxtbrand = mSocketThread.waitRead();
                                Log.d("TAG", stxtbrand);
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        txtbrand.setText(stxtbrand);
                                    }
                                });

                                final String stxtname = mSocketThread.waitRead();
                                Log.d("TAG", stxtname);
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        txtname.setText(stxtname);
                                    }
                                });

                                final String stxtcode = mSocketThread.waitRead();
                                Log.d("TAG", stxtcode);
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        txtcode.setText(stxtcode);
                                    }
                                });

                                final String stxtmoney = mSocketThread.waitRead();
                                Log.d("TAG", stxtmoney);
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        txtmoney.setText(stxtmoney);
                                    }
                                });

                                final String stxtstock = mSocketThread.waitRead();
                                Log.d("TAG", stxtbrand);
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        txtstock.setText(stxtstock);
                                    }
                                });

                            }
                        } catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                }).start();

            }
        });
        Button btn2 = (Button)findViewById(R.id.turnbtn);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("hi","end");
                mSocketThread.SocketStop();
                finish();
            }
        });

    }

}
