package com.example.smartfactory;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.util.LinkedList;

public class EmployeerManager extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employeer_manager);

        final SocketThread mSocketThread = SocketThread.getInstanse();
        mSocketThread.initSocket();

        Button button = (Button) findViewById(R.id.turnbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                mSocketThread.SocketStop();
            }
        });
        Button button2 = (Button) findViewById(R.id.choice);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ChoiceMember.class);
                startActivity(intent);
                mSocketThread.SocketStop();
            }
        });
        Button button3 = (Button) findViewById(R.id.redraw);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), RedrawEmployeer.class);
                startActivity(intent);
                mSocketThread.SocketStop();

            }
        });
    }
}
