package com.example.smartfactory;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class EmployeerMenu extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employeer_menu);

        final SocketThread mSocketThread = SocketThread.getInstanse();
        mSocketThread.initSocket();

        Button button = (Button) findViewById(R.id.stockbtn1);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), StockCheck.class);
                startActivity(intent);
                mSocketThread.SocketStop();
            }
        });
        Button button2 = (Button) findViewById(R.id.logoutbtn);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();

            }
        });
        Button button3 = (Button) findViewById(R.id.goodsbtn);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), GoodsCheck.class);
                startActivity(intent);
                mSocketThread.SocketStop();

            }
        });
    }


}
