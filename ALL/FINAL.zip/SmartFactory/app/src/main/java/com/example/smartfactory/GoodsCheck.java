package com.example.smartfactory;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.LinkedList;


public class GoodsCheck extends Activity {

    static String sNum1 = "";
    static String sNum2 = "";
    static String sNum3 = "";
    static String sNum4 = "";
    static String sNum5 = "";
    String []Arr = new String[30];


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goods_check);

        final SocketThread mSocketThread = SocketThread.getInstanse();
        mSocketThread.initSocket();
        final TextView txt = (TextView)findViewById(R.id.txtbrand);
        final TextView txt2 = (TextView)findViewById(R.id.txtcode);
        final TextView txt3 = (TextView)findViewById(R.id.txtname);
        final TextView txt4 = (TextView)findViewById(R.id.txtsales);
        final TextView txt5 = (TextView)findViewById(R.id.txtstock);


                    Button button2 = (Button) findViewById(R.id.click);
                    button2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            new Thread(){
                                public void run() {
                                    try {
                                        String pleaseLogin = "check";
                                        mSocketThread.socketWriter(pleaseLogin);

                                        String contextgoods = mSocketThread.getData();
                                        Log.d("TAG", contextgoods);
                                        final int peoplecnt = Integer.parseInt(contextgoods);

                                        if (contextgoods != null) {
                                            pleaseLogin = "ok";
                                            mSocketThread.socketWriter(pleaseLogin);
                                            Log.d("TAG", pleaseLogin);
                                        }
                                        int num = 1;
                                        if (num == 1) {
                                            try {
                                                for (int i = 0; i < peoplecnt; i++) {
                                                    try {
                                                        Arr[i] = mSocketThread.getData() + "\n";
                                                        Log.d("TAG", Arr[i]);
                                                    } catch (Exception e) {
                                                        e.printStackTrace();
                                                    }
                                                }
                                                for (int i = 0; i < peoplecnt; i++) {
                                                    sNum1 += Arr[i];
                                                }

                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                            num++;
                                        }
                                        if (num == 2) {
                                            try {
                                                for (int i = 0; i < peoplecnt; i++) {
                                                    try {
                                                        Arr[i] = mSocketThread.getData() + "\n";
                                                        Log.d("TAG", Arr[i]);
                                                    } catch (Exception e) {
                                                        e.printStackTrace();
                                                    }
                                                }
                                                for (int i = 0; i < peoplecnt; i++) {
                                                    sNum2 += Arr[i];
                                                }

                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                            num++;
                                        }
                                        if (num == 3) {
                                            try {
                                                for (int i = 0; i < peoplecnt; i++) {
                                                    try {
                                                        Arr[i] = mSocketThread.getData() + "\n";
                                                        Log.d("TAG", Arr[i]);
                                                    } catch (Exception e) {
                                                        e.printStackTrace();
                                                    }
                                                }
                                                for (int i = 0; i < peoplecnt; i++) {
                                                    sNum3 += Arr[i];
                                                }

                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                            num++;
                                        }
                                        if (num == 4) {
                                            try {
                                                for (int i = 0; i < peoplecnt; i++) {
                                                    try {
                                                        Arr[i] = mSocketThread.getData() + "\n";
                                                        Log.d("TAG", Arr[i]);
                                                    } catch (Exception e) {
                                                        e.printStackTrace();
                                                    }
                                                }
                                                for (int i = 0; i < peoplecnt; i++) {
                                                    sNum4 += Arr[i];
                                                }

                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                            num++;
                                        }
                                        if (num == 5) {
                                            try {
                                                for (int i = 0; i < peoplecnt; i++) {
                                                    try {
                                                        Arr[i] = mSocketThread.getData() + "\n";
                                                        Log.d("TAG", Arr[i]);
                                                    } catch (Exception e) {
                                                        e.printStackTrace();
                                                    }
                                                }
                                                for (int i = 0; i < peoplecnt; i++) {
                                                    sNum5 += Arr[i];
                                                }
                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }
                                            num++;
                                        }
                                        runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                txt.setText(sNum1);
                                                txt2.setText(sNum2);
                                                txt3.setText(sNum3);
                                                txt4.setText(sNum4);
                                                txt5.setText(sNum5);
                                            }
                                        });

                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                                }.start();
                    }
                    });



        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), RepairGoods.class);
                startActivity(intent);
                mSocketThread.SocketStop();
            };
            });
        Button button3 = (Button) findViewById(R.id.turnbtn);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                mSocketThread.SocketStop();
            }
        });
        Button button4 = (Button) findViewById(R.id.button2);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Plus_goods.class);
                startActivity(intent);
                mSocketThread.SocketStop();
            }
        });

        Button button5 = (Button) findViewById(R.id.button3);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), DeleteGoods.class);
                startActivity(intent);
                mSocketThread.SocketStop();
            }
        });
    }


}
