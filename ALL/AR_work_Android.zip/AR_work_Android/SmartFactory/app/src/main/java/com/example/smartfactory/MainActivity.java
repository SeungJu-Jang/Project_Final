package com.example.smartfactory;


import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.os.StrictMode;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.List;

import android.app.Activity;


import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;


import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;

import org.apache.http.client.methods.HttpPost;

import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;


public class MainActivity extends Activity {


    EditText inputID, inputPW;
    HttpPost httppost;
    StringBuffer buffer;
    org.apache.http.HttpResponse response;
    HttpClient httpclient;
    List<NameValuePair> nameValuePairs;
    AlertDialog dialog;
    //TextView tv;

    private BackClickHandler backClickHandler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        inputID = (EditText) findViewById(R.id.us_id);
        inputPW = (EditText) findViewById(R.id.us_pw);


        backClickHandler = new BackClickHandler(this);

        Button button = (Button) findViewById(R.id.loginbtn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String userID = inputID.getText().toString();

                String userPassword = inputPW.getText().toString();

                Response.Listener<String> responseListener = new Response.Listener<String>(){

                    @Override

                    public void onResponse(String response) {

                        try{
                            JSONObject jsonResponse = new JSONObject(response);

                            boolean success = jsonResponse.getBoolean("success");

                            if(success){

                                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

                                builder.setMessage("로그인 성공!");
                                builder.setPositiveButton("확인", null);
                                builder.create().show();

                                Intent intent = new Intent(MainActivity.this, ManagerMenu.class);
                                MainActivity.this.startActivity(intent);

                                finish();

                            }else {

                                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

                                builder.setTitle("오류");
                                builder.setMessage("로그인 실패");
                                builder.setNegativeButton("다시시도", null);
                                builder.create().show();

                                //finish();

                            }

                        }catch (Exception e){

                            e.printStackTrace();

                        }

                    }

                };

                LoginRequest loginRequest = new LoginRequest(userID, userPassword, responseListener);

                RequestQueue queue = Volley.newRequestQueue(MainActivity.this);

                queue.add(loginRequest);

            }

        });


        Button button2 = (Button) findViewById(R.id.joinbtn);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent2 = new Intent(getApplicationContext(), JoinActivity.class);
                startActivity(intent2);
            }
        });
    }

    public void onBackPressed(){
        backClickHandler.onBackPressed();
    }
}

